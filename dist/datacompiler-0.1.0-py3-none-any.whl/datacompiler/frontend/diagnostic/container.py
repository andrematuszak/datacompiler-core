﻿"""container.py — Signaux tirés des métadonnées du conteneur PDF, pas du
contenu extrait.

PRODUCTEURS_SUSPECTS est VOLONTAIREMENT VIDE au départ : je n'ai aucune
preuve empirique que tel ou tel producteur produit systématiquement du
texte corrompu. À peupler UNIQUEMENT quand un de vos tests le confirme,
pas par supposition."""

from typing import Optional

PRODUCTEURS_SUSPECTS = set()


def producteur_suspect(doc) -> Optional[str]:
    producer = (doc.metadata.producer or "").strip()
    creator = (doc.metadata.creator or "").strip()
    for nom in PRODUCTEURS_SUSPECTS:
        if nom.lower() in producer.lower() or nom.lower() in creator.lower():
            return producer or creator
    return None

