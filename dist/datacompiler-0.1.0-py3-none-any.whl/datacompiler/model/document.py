"""document.py — Assemblage du modèle : Word (le nœud central, référencé
depuis native/ocr/resolved), conteneurs de page, Page, Document."""

import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from datacompiler.model.geometry import BBox, Polygon
from datacompiler.model.font import Font
from datacompiler.model.metadata import Diagnostic, Metadata


@dataclass
class Decision:
    regle: str
    detail: str = ""

@dataclass
class Flag:
    type: str
    detail: str = ""
    severity: str = "info"  # "info" | "warning" | "critical"


@dataclass
class Word:
    id: int
    text: str
    bbox: Optional[BBox] = None
    block: int = 0
    line: int = 0
    word: int = 0
    font: str = "Unknown"
    font_size: float = 0.0
    bold: bool = False
    italic: bool = False
    color: str = "#000000"
    rotation: float = 0.0
    confidence: Optional[float] = None
    language: Optional[str] = None
    source: Optional[str] = None
    resolved_text: Optional[str] = None
    reconstructed: bool = False
    is_corrected: bool = False
    replacement: Optional[str] = None
    decision: Optional[Decision] = None
    notes: List[str] = field(default_factory=list)
    is_vectorized: bool = False
    flags: List[Flag] = field(default_factory=list)
    # Densite d'encre relative au fond local (0-1), calculee UNIQUEMENT pour
    # les mots recuperes par OCR vectoriel (cf. ocr/paddle.py
    # _ratio_encre_relatif / _ratio_encre_connue). PLUS UTILISEE pour decider
    # `bold` depuis la session du 26/09/2026 (cf. stroke_width ci-dessous) --
    # invalidee empiriquement sur "DIRECTION" : sans marge blanche disponible
    # autour du mot (crop colle a un mot natif voisin), la densite relative a
    # la bbox du mot se confond avec celle d'un mot gras, quelle que soit la
    # methode d'estimation du fond (bordure ou couleur d'encre connue).
    # Conservee a titre diagnostique/traçable (cf. notes) uniquement.
    ink_ratio: Optional[float] = None
    # Epaisseur de trait estimee en points (2*Aire/Perimetre du tracé
    # vectoriel de CHAQUE glyphe, mediane par mot) -- cf. ocr/vector_zones.py
    # _epaisseur_mediane_zone. Calculee en espace VECTORIEL directement
    # depuis get_drawings(), independamment de tout raster/DPI/marge de crop
    # -- remplace ink_ratio comme critere de decision pour `bold` (mots
    # vectorises uniquement). Insensible a la forme de la lettre (I vs O),
    # contrairement a une densite aire/bbox -- valide empiriquement sur
    # test-impots-revenu.pdf (session du 26/09/2026) : separation nette
    # (~0,84-0,88 non-gras vs ~1,01-1,54 gras, seuil Otsu a 0,93). None pour
    # tout mot natif (pas de tracé vectoriel a mesurer) ou non mesure.
    stroke_width: Optional[float] = None

    @property
    def output_text(self) -> str:
        return self.resolved_text or self.replacement or self.text


@dataclass
class LayoutBox:
    bbox: Optional[BBox] = None
    type: str = "container"
    reading_order: int = 0
    word_ids: List[int] = field(default_factory=list)
    children: List["LayoutBox"] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)  # <-- ajouter cette ligne
    

@dataclass
class NativeContainer:
    words: List[Word] = field(default_factory=list)
    fonts: List[Font] = field(default_factory=list)


@dataclass
class ImageElement:
    id: int
    bbox: Optional[BBox] = None
    width: Optional[int] = None
    height: Optional[int] = None
    source: str = "original_pdf"
    keep_original: bool = True
    contains_text: Optional[bool] = None


@dataclass
class TableElement:
    id: int
    bbox: Optional[BBox] = None
    source: str = "pdfplumber"
    rows: List[List[Optional[str]]] = field(default_factory=list)
    cell_bboxes: List[List[Optional[BBox]]] = field(default_factory=list)
    keep_original: bool = True


@dataclass
class GraphicVector:
    bbox: Optional[BBox] = None
    keep_original: bool = True
    color: Optional[str] = None  # hex "#rrggbb", ex. les encadrés colorés (cf. frontend/layout/detectors.py)


@dataclass
class GraphicsContainer:
    images: List[ImageElement] = field(default_factory=list)
    tables: List[TableElement] = field(default_factory=list)
    lines: List[GraphicVector] = field(default_factory=list)
    rects: List[GraphicVector] = field(default_factory=list)
    curves: List[GraphicVector] = field(default_factory=list)


@dataclass
class OcrBlock:
    bbox: Optional[BBox] = None
    type: str = "text"
    content: str = ""


@dataclass
class OcrContainer:
    engine: Optional[str] = None
    words: List[Word] = field(default_factory=list)
    blocks: List[OcrBlock] = field(default_factory=list)


@dataclass
class ResolvedContainer:
    words: List[Word] = field(default_factory=list)
    images: List[ImageElement] = field(default_factory=list)
    tables: List[TableElement] = field(default_factory=list)
    fonts: List[Font] = field(default_factory=list)  # Polices résolues pour le rendu


@dataclass
class Page:
    number: int
    width: float
    height: float
    rotation: float = 0.0
    diagnostic: Diagnostic = field(default_factory=Diagnostic)
    native: NativeContainer = field(default_factory=NativeContainer)
    graphics: GraphicsContainer = field(default_factory=GraphicsContainer)
    ocr: OcrContainer = field(default_factory=OcrContainer)
    resolved: ResolvedContainer = field(default_factory=ResolvedContainer)
    layout_root: Optional[LayoutBox] = None
    # Rectangles des liens (annotations /Link) de la page, (x0, y0, x1, y1). Provisoire : sert
    # à exclure de la détection de texte vectorisé les zones cliquables, qui seront traitées
    # à part dans l'extraction.
    link_rects: List[Tuple[float, float, float, float]] = field(default_factory=list)


@dataclass
class Document:
    metadata: Metadata = field(default_factory=Metadata)
    diagnostic: Diagnostic = field(default_factory=Diagnostic)
    pages: List[Page] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data.pop("diagnostic", None)
        return data

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(self.to_json())

    @classmethod
    def load(cls, path: str) -> "Document":
        with open(path, encoding="utf-8") as handle:
            return cls.from_dict(json.load(handle))

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Document":
        def decision(d):
            if not d:
                return None
            return Decision(**{k: v for k, v in d.items() if k in Decision.__dataclass_fields__})

        def font_obj(d):
            if not d:
                return None
            return Font(**{k: v for k, v in d.items() if k in Font.__dataclass_fields__})

        def word(d):
            d = dict(d)
            d["bbox"] = BBox.from_dict(d.get("bbox"))
            d["decision"] = decision(d.get("decision"))
            return Word(**{k: v for k, v in d.items() if k in Word.__dataclass_fields__})

        def page_diagnostic(d):
            if not d:
                return Diagnostic()
            return Diagnostic(**{k: v for k, v in d.items() if k in Diagnostic.__dataclass_fields__})

        def image(d):
            d = dict(d)
            d["bbox"] = BBox.from_dict(d.get("bbox"))
            return ImageElement(**{k: v for k, v in d.items() if k in ImageElement.__dataclass_fields__})

        def table(d):
            d = dict(d)
            d["bbox"] = BBox.from_dict(d.get("bbox"))
            d["cell_bboxes"] = [
                [BBox.from_dict(cell) for cell in ligne]
                for ligne in d.get("cell_bboxes", [])
            ]
            return TableElement(**{k: v for k, v in d.items() if k in TableElement.__dataclass_fields__})

        def layout_box(d):
            if not d:
                return None
            return LayoutBox(
                bbox=BBox.from_dict(d.get("bbox")),
                type=d.get("type", "container"),
                reading_order=d.get("reading_order", 0),
                word_ids=list(d.get("word_ids", [])),
                children=[layout_box(c) for c in d.get("children", [])],
                metadata=dict(d.get("metadata", {})),  # <-- ajouter cette ligne
            )

        pages = []
        for raw in data.get("pages", []):
            native = raw.get("native", {})
            graphics = raw.get("graphics", {})
            ocr = raw.get("ocr", {})
            resolved = raw.get("resolved", {})
            page = Page(number=raw["number"], width=raw["width"], height=raw["height"], rotation=raw.get("rotation", 0.0))
            page.diagnostic = page_diagnostic(raw.get("diagnostic", {}))
            
            # Utilisation du helper sécurisé font_obj
            page.native = NativeContainer(
                words=[word(x) for x in native.get("words", [])],
                fonts=[font_obj(x) for x in native.get("fonts", []) if x]
            )
            page.graphics = GraphicsContainer(
                images=[image(x) for x in graphics.get("images", [])],
                tables=[table(x) for x in graphics.get("tables", [])]
            )
            page.ocr = OcrContainer(
                engine=ocr.get("engine"),
                words=[word(x) for x in ocr.get("words", [])],
                blocks=[OcrBlock(BBox.from_dict(x.get("bbox")), x.get("type", "text"), x.get("content", "")) for x in ocr.get("blocks", [])]
            )
            page.resolved = ResolvedContainer(
                words=[word(x) for x in resolved.get("words", [])],
                images=[image(x) for x in resolved.get("images", [])],
                tables=[table(x) for x in resolved.get("tables", [])],
                fonts=[font_obj(x) for x in resolved.get("fonts", []) if x]
            )
            page.layout_root = layout_box(raw.get("layout_root"))
            pages.append(page)

        metadata = Metadata(**{k: v for k, v in data.get("metadata", {}).items() if k in Metadata.__dataclass_fields__})
        diagnostic = Diagnostic(**{k: v for k, v in data.get("diagnostic", {}).items() if k in Diagnostic.__dataclass_fields__})
        return cls(metadata=metadata, diagnostic=diagnostic, pages=pages)
